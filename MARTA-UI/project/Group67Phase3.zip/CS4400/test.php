

<?php


include "db_info.php";
$s = Get_Station_name("11");
echo $s;

?>






